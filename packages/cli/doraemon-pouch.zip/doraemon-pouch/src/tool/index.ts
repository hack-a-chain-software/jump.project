import inquirer from "inquirer";
import { createSubAccount } from "./createSubAccount.js";
export async function toolEntry(masterId: string) {
  const questions = [
    {
      type: "list",
      name: "operation",
      message: "[Tools] Select operation",
      choices: ["Create Sub Account", "Exit"],
    },
  ];

  const { operation } = await inquirer.prompt(questions);

  switch (operation) {
    case "Create Sub Account":
      await createSubAccount();
  }
}
